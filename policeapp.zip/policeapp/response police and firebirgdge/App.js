import React from 'react';
import AppNavigator from './config/navigator';


function App() {
  
  return (
  

    <AppNavigator />
   
  );
};


export default App;